
export const Search = () => {
  return (
    <div>Search</div>
  )
}
