
export const DcHeroes = () => {
  return (
    <div>DcHeroes</div>
  )
}
