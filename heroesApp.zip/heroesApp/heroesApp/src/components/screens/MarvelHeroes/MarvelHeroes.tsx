
export const MarvelHeroes = () => {
  return (
    <div>MarvelHeroes</div>
  )
}
